"use client";
import { useState } from "react";
import { loginAdmin } from "@/lib/auth";
import { useRouter } from "next/navigation";

// This route is intentionally not linked from anywhere in the UI.
// Real protection = it isn't discoverable + the account itself must have
// role:'admin' set in Firestore (see README "Creating the first admin").
export default function SecureAdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const submit = async () => {
    setErr("");
    setLoading(true);
    try {
      await loginAdmin({ email, password, rememberMe: remember });
      router.push("/");
    } catch (e) {
      setErr(e.message.replace("Firebase: ", ""));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-5 pt-16">
      <div className="text-center mb-6 text-3xl">🔒</div>
      <div className="font-display font-bold text-lg text-center mb-1">গোপন অ্যাডমিন লগইন</div>
      <div className="text-xs opacity-60 text-center mb-6">শুধুমাত্র অনুমোদিত অ্যাডমিনদের জন্য</div>

      <div className="flex flex-col gap-3">
        <input placeholder="অ্যাডমিন ইমেইল" type="email" className="border rounded-xl p-3" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input placeholder="পাসওয়ার্ড" type="password" className="border rounded-xl p-3" value={password} onChange={(e) => setPassword(e.target.value)} />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
          মনে রাখুন
        </label>
        {err && <div className="text-due text-sm">{err}</div>}
        <button disabled={loading} onClick={submit} className="bg-deep text-white font-bold py-3 rounded-xl">
          {loading ? "যাচাই করা হচ্ছে..." : "প্রবেশ করুন"}
        </button>
      </div>
    </div>
  );
}
