"use client";
import { useEffect, useState } from "react";
import { watchAuthState } from "@/lib/auth";
import { listenToUserProfile } from "@/lib/firestore-helpers";
import BottomNav from "@/components/BottomNav";

export default function OfferPage() {
  const [profile, setProfile] = useState(null);
  useEffect(() => {
    const unsub = watchAuthState((u) => {
      if (u) listenToUserProfile(u.uid, setProfile);
    });
    return () => unsub();
  }, []);

  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 rounded-b-3xl">
        <div className="font-display font-bold text-lg">অফার ও লয়্যালটি</div>
        <div className="text-xs opacity-85">প্রতি ১০০ টাকায় ১ কয়েন পান</div>
      </div>
      <div className="p-4 flex flex-col gap-3">
        <div className="card p-4">
          <div className="font-semibold text-gold">রিওয়ার্ড কয়েন</div>
          <div className="font-display font-extrabold text-2xl my-1">{profile?.coins ?? 0} কয়েন</div>
          <div className="text-xs opacity-60">= ৳{profile?.coins ?? 0} ছাড় হিসেবে ব্যবহার করা যাবে</div>
        </div>
        <div className="card p-4">
          <div className="font-semibold mb-1">🎁 রেফারেল প্রোগ্রাম</div>
          <div className="text-xs opacity-60">বন্ধুকে রেফার করে ওয়ালেট কমিশন পান — আপনার কোড প্রোফাইল পেজে</div>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
