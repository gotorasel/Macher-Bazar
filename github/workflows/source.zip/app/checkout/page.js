"use client";
import { useEffect, useState } from "react";
import { watchAuthState } from "@/lib/auth";
import { placeOrder } from "@/lib/firestore-helpers";
import { useRouter } from "next/navigation";
import BottomNav from "@/components/BottomNav";

export default function Checkout() {
  const [cart, setCart] = useState([]);
  const [paymentType, setPaymentType] = useState("নগদ");
  const [user, setUser] = useState(null);
  const [placing, setPlacing] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const saved = localStorage.getItem("mb_cart");
    if (saved) setCart(JSON.parse(saved));
    const unsub = watchAuthState(setUser);
    return () => unsub();
  }, []);

  const total = cart.reduce((a, c) => a + c.price * c.qty, 0);

  const changeQty = (id, delta) => {
    const updated = cart.map((c) => (c.id === id ? { ...c, qty: Math.max(1, c.qty + delta) } : c));
    setCart(updated);
    localStorage.setItem("mb_cart", JSON.stringify(updated));
  };

  const confirmOrder = async () => {
    if (!user) {
      router.push("/login");
      return;
    }
    setPlacing(true);
    try {
      await placeOrder({
        userId: user.uid,
        items: cart.map((c) => ({ fishId: c.id, name: c.name, qty: c.qty, price: c.price })),
        total,
        paymentType,
      });
      localStorage.removeItem("mb_cart");
      router.push("/profile");
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 rounded-b-3xl">
        <div className="font-display font-bold text-lg">চেকআউট</div>
      </div>

      <div className="p-4 flex flex-col gap-2.5">
        {cart.length === 0 && <div className="card p-6 text-center opacity-60">আপনার কার্ট খালি</div>}
        {cart.map((c) => (
          <div key={c.id} className="card p-3 flex justify-between items-center">
            <div>
              <div className="font-bold text-sm">{c.name}</div>
              <div className="text-xs opacity-60">৳{c.price} × {c.qty} {c.unit}</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => changeQty(c.id, -1)} className="w-6 h-6 rounded-full bg-gray-200">−</button>
              <span className="font-bold">{c.qty}</span>
              <button onClick={() => changeQty(c.id, 1)} className="w-6 h-6 rounded-full bg-gray-200">+</button>
            </div>
          </div>
        ))}

        {cart.length > 0 && (
          <div className="card p-4">
            <div className="text-xs font-semibold opacity-70 mb-2">পেমেন্ট ধরন</div>
            <div className="flex gap-2 mb-3">
              <button
                onClick={() => setPaymentType("নগদ")}
                className={`flex-1 py-2 rounded-full font-semibold text-sm ${paymentType === "নগদ" ? "bg-mint text-leaf2" : "bg-gray-100"}`}
              >
                নগদ
              </button>
              <button
                onClick={() => setPaymentType("বাকি")}
                className={`flex-1 py-2 rounded-full font-semibold text-sm ${paymentType === "বাকি" ? "bg-red-100 text-due" : "bg-gray-100"}`}
              >
                বাকি
              </button>
            </div>
            <div className="flex justify-between font-bold text-lg pt-2 border-t">
              <span>সর্বমোট</span>
              <span className="text-leaf2">৳{total.toLocaleString()}</span>
            </div>
          </div>
        )}

        {cart.length > 0 && (
          <button disabled={placing} onClick={confirmOrder} className="bg-leaf2 text-white font-bold py-3 rounded-xl">
            {placing ? "অপেক্ষা করুন..." : "অর্ডার নিশ্চিত করুন"}
          </button>
        )}
      </div>
      <BottomNav />
    </div>
  );
}
