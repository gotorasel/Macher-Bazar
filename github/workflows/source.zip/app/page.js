"use client";
import { useEffect, useState } from "react";
import { watchAuthState } from "@/lib/auth";
import {
  listenToFishCatalog,
  listenToUserProfile,
  listenToAllDues,
  broadcastDueReminders,
} from "@/lib/firestore-helpers";
import FishCard from "@/components/FishCard";
import BottomNav from "@/components/BottomNav";
import Link from "next/link";

export default function Home() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [fish, setFish] = useState([]);
  const [dues, setDues] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem("mb_cart");
    if (saved) setCart(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("mb_cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    const unsubAuth = watchAuthState((u) => setUser(u));
    const unsubFish = listenToFishCatalog(setFish);
    return () => {
      unsubAuth();
      unsubFish();
    };
  }, []);

  useEffect(() => {
    if (!user) return;
    const unsub = listenToUserProfile(user.uid, setProfile);
    return () => unsub();
  }, [user]);

  useEffect(() => {
    if (profile?.role === "admin") {
      const unsub = listenToAllDues(setDues);
      return () => unsub();
    }
  }, [profile]);

  const isAdmin = profile?.role === "admin";
  const totalDue = dues.reduce((a, d) => a + d.amount, 0);
  const totalStock = fish.reduce((a, f) => a + (f.stock || 0), 0);

  const addToCart = (f) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.id === f.id);
      if (existing) return prev.map((c) => (c.id === f.id ? { ...c, qty: c.qty + 1 } : c));
      return [...prev, { ...f, qty: 1 }];
    });
  };

  return (
    <div>
      {/* Header */}
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 pb-6 rounded-b-3xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-full overflow-hidden border-2 border-white/60 bg-white shrink-0">
              <img src="/icon-192.png" alt="logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="font-display font-bold text-[19px] leading-tight">মাছের বাজার</div>
              <div className="text-[11px] opacity-85">নদী ও খামারের তাজা মাছ, হাতের মুঠোয়</div>
            </div>
          </div>
          {!user && (
            <Link href="/login" className="text-[12px] font-semibold bg-white/15 px-3 py-1.5 rounded-full">
              লগইন
            </Link>
          )}
        </div>

        <div className="flex gap-2 mt-4">
          {isAdmin ? (
            <>
              <div className="flex-1 bg-white/10 rounded-2xl p-2.5">
                <div className="text-[11px] opacity-70">মোট স্টক</div>
                <div className="font-display font-bold text-[16px]">{totalStock} কেজি</div>
              </div>
              <Link href="/admin/dues" className="flex-1 bg-white/10 rounded-2xl p-2.5">
                <div className="text-[11px] opacity-70">মোট বাকি</div>
                <div className="font-display font-bold text-[16px]">৳{totalDue.toLocaleString()}</div>
              </Link>
            </>
          ) : (
            <>
              <div className="flex-1 bg-white/10 rounded-2xl p-2.5">
                <div className="text-[11px] opacity-70">রিওয়ার্ড কয়েন</div>
                <div className="font-display font-bold text-[16px]">{profile?.coins ?? 0}</div>
              </div>
              <div className="flex-1 bg-white/10 rounded-2xl p-2.5">
                <div className="text-[11px] opacity-70">কার্টে আইটেম</div>
                <div className="font-display font-bold text-[16px]">{cart.length}</div>
              </div>
            </>
          )}
        </div>

        {isAdmin && dues.length > 0 && (
          <button
            onClick={() => broadcastDueReminders(dues)}
            className="mt-3 text-[12px] font-semibold bg-white/15 px-3 py-1.5 rounded-full"
          >
            সবাইকে বাকি রিমাইন্ডার পাঠান
          </button>
        )}
      </div>

      {/* Catalog */}
      <div className="p-4 flex flex-col gap-2.5">
        <div className="font-display font-bold text-[15px]">
          {isAdmin ? "সব মাছ" : "আজকের তাজা মাছ"}
        </div>
        {fish.length === 0 && (
          <div className="card p-6 text-center text-sm opacity-60">
            এখনো কোনো মাছ যোগ করা হয়নি। অ্যাডমিন প্যানেল থেকে যোগ করুন।
          </div>
        )}
        {fish.map((f) => (
          <FishCard
            key={f.id}
            fish={f}
            isAdmin={isAdmin}
            onAddToCart={addToCart}
            onEditPrice={(f) => (window.location.href = `/admin/stock?edit=${f.id}`)}
          />
        ))}
      </div>

      {!isAdmin && cart.length > 0 && (
        <div className="fixed bottom-16 left-1/2 -translate-x-1/2 w-full max-w-[460px] px-4">
          <Link
            href="/checkout"
            className="block text-center bg-leaf2 text-white font-bold py-3 rounded-2xl shadow-lg"
          >
            কার্ট দেখুন ({cart.length}) · চেকআউট
          </Link>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
