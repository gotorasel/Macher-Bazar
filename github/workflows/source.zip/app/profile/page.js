"use client";
import { useEffect, useState } from "react";
import { watchAuthState, logout } from "@/lib/auth";
import { listenToUserProfile, listenToUserOrders } from "@/lib/firestore-helpers";
import BottomNav from "@/components/BottomNav";
import { useRouter } from "next/navigation";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [orders, setOrders] = useState([]);
  const [dark, setDark] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const unsub = watchAuthState(setUser);
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!user) return;
    const unsub1 = listenToUserProfile(user.uid, setProfile);
    const unsub2 = listenToUserOrders(user.uid, setOrders);
    return () => {
      unsub1();
      unsub2();
    };
  }, [user]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  if (!user) {
    return (
      <div className="p-6 text-center pt-20">
        <div className="opacity-60 mb-4">প্রোফাইল দেখতে লগইন করুন</div>
        <button onClick={() => router.push("/login")} className="bg-leaf2 text-white font-bold px-5 py-2.5 rounded-xl">
          লগইন করুন
        </button>
        <BottomNav />
      </div>
    );
  }

  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 pb-6 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-full bg-gold/30 flex items-center justify-center text-2xl">👤</div>
          <div>
            <div className="font-display font-bold text-lg">{profile?.name || "..."}</div>
            <div className="text-xs opacity-85">{profile?.phone}</div>
          </div>
        </div>
      </div>

      <div className="p-4 flex flex-col gap-2.5">
        <div className="card flex">
          <div className="flex-1 p-3 text-center border-r">
            <div className="font-bold text-gold">{profile?.coins ?? 0}</div>
            <div className="text-xs opacity-60">কয়েন</div>
          </div>
          <div className="flex-1 p-3 text-center">
            <div className="font-bold text-leaf2">৳{profile?.wallet ?? 0}</div>
            <div className="text-xs opacity-60">ওয়ালেট</div>
          </div>
        </div>

        <div className="card p-4">
          <div className="font-semibold text-sm mb-1">🎁 রেফারেল কোড</div>
          <div className="flex gap-2">
            <input readOnly value={profile?.referralCode || ""} className="border rounded-xl p-2 flex-1 font-bold" />
          </div>
        </div>

        <div className="card p-1">
          <a href="/pay" className="flex items-center gap-3 p-3 border-b">
            <span className="text-lg">💳</span>
            <span className="flex-1 font-semibold text-sm">bKash / Nagad পেমেন্ট</span>
            <span className="opacity-40">›</span>
          </a>
          {profile?.role === "admin" && (
            <a href="/admin/settings" className="flex items-center gap-3 p-3">
              <span className="text-lg">⚙️</span>
              <span className="flex-1 font-semibold text-sm">পেমেন্ট নম্বর সেটিংস</span>
              <span className="opacity-40">›</span>
            </a>
          )}
        </div>

        <div className="card p-4">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-sm">ডার্ক মোড</span>
            <input type="checkbox" checked={dark} onChange={(e) => setDark(e.target.checked)} />
          </div>
        </div>

        <div className="font-display font-bold text-sm mt-2">আমার অর্ডার</div>
        {orders.length === 0 && <div className="card p-4 text-center opacity-60 text-sm">কোনো অর্ডার নেই</div>}
        {orders.map((o) => (
          <div key={o.id} className="card p-3">
            <div className="flex justify-between">
              <span className="font-bold text-sm">{o.id.slice(0, 8)}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${o.paymentType === "নগদ" ? "bg-mint text-leaf2" : "bg-red-100 text-due"}`}>
                {o.paymentType}
              </span>
            </div>
            <div className="text-xs opacity-60 mt-1">
              {o.items?.map((i) => `${i.name} ${i.qty}`).join(", ")}
            </div>
            <div className="font-bold text-leaf2 mt-1">৳{o.total?.toLocaleString()}</div>
          </div>
        ))}

        <button onClick={() => logout().then(() => router.push("/"))} className="border border-due text-due font-bold py-3 rounded-xl mt-2">
          লগআউট
        </button>
      </div>
      <BottomNav />
    </div>
  );
}
