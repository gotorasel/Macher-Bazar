"use client";
import { useEffect, useState } from "react";
import { listenToFishCatalog } from "@/lib/firestore-helpers";
import FishCard from "@/components/FishCard";
import BottomNav from "@/components/BottomNav";

export default function PricePage() {
  const [fish, setFish] = useState([]);
  useEffect(() => listenToFishCatalog(setFish), []);
  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 rounded-b-3xl">
        <div className="font-display font-bold text-lg">মূল্য তালিকা</div>
      </div>
      <div className="p-4 flex flex-col gap-2.5">
        {fish.map((f) => (
          <FishCard key={f.id} fish={f} isAdmin={false} onAddToCart={() => {}} />
        ))}
      </div>
      <BottomNav />
    </div>
  );
}
