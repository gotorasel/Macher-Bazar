import "./globals.css";
import AdminShortcut from "@/components/AdminShortcut";

export const metadata = {
  title: "মাছের বাজার",
  description: "নদী ও খামারের তাজা মাছ, এখন আপনার হাতের মুঠোয়— 'মাছের বাজার'।",
  manifest: "/manifest.json",
  themeColor: "#0F3D2E",
};

export default function RootLayout({ children }) {
  return (
    <html lang="bn">
      <body>
        <AdminShortcut />
        <div className="max-w-[460px] mx-auto min-h-screen relative pb-24">
          {children}
        </div>
      </body>
    </html>
  );
}
