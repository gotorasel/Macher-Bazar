"use client";
import { useEffect, useState } from "react";
import { watchAuthState } from "@/lib/auth";
import { listenToUserProfile, listenToPaymentSettings, submitPaymentReference, findPaymentByTrxId, verifyPayment } from "@/lib/firestore-helpers";
import BottomNav from "@/components/BottomNav";

export default function PayPage() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [settings, setSettings] = useState({ bkashNumber: "", nagadNumber: "" });
  const [method, setMethod] = useState("bkash");
  const [trxId, setTrxId] = useState("");
  const [amount, setAmount] = useState("");
  const [searchTrx, setSearchTrx] = useState("");
  const [foundPayments, setFoundPayments] = useState([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const unsub = watchAuthState((u) => {
      setUser(u);
      if (u) listenToUserProfile(u.uid, setProfile);
    });
    const unsubSettings = listenToPaymentSettings(setSettings);
    return () => {
      unsub();
      unsubSettings();
    };
  }, []);

  const isAdmin = profile?.role === "admin";

  const submit = async () => {
    if (!user || !trxId || !amount) return;
    await submitPaymentReference({ userId: user.uid, method, trxId, amount: parseFloat(amount) });
    setMsg("যাচাইয়ের জন্য পাঠানো হয়েছে ✓");
    setTrxId("");
    setAmount("");
  };

  const search = async () => {
    const results = await findPaymentByTrxId(searchTrx);
    setFoundPayments(results);
  };

  const approve = async (id) => {
    await verifyPayment(id);
    search();
  };

  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 rounded-b-3xl">
        <div className="font-display font-bold text-lg">bKash / Nagad পেমেন্ট</div>
      </div>

      <div className="p-4 flex flex-col gap-3">
        {!isAdmin && (
          <div className="card p-4">
            <label className="text-xs font-semibold opacity-70">পেমেন্ট মেথড</label>
            <div className="flex gap-2 my-2">
              <button onClick={() => setMethod("bkash")} className={`flex-1 py-2 rounded-full font-semibold text-sm ${method === "bkash" ? "bg-pink-100 text-pink-600" : "bg-gray-100"}`}>bKash</button>
              <button onClick={() => setMethod("nagad")} className={`flex-1 py-2 rounded-full font-semibold text-sm ${method === "nagad" ? "bg-orange-100 text-orange-600" : "bg-gray-100"}`}>Nagad</button>
            </div>
            <div className="text-sm mb-3 p-2 bg-mint rounded-xl">
              <b>{method === "bkash" ? "bKash" : "Nagad"} Send Money নম্বর:</b>{" "}
              {method === "bkash" ? settings.bkashNumber : settings.nagadNumber}
            </div>
            <label className="text-xs font-semibold opacity-70">পরিমাণ (৳)</label>
            <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" className="border rounded-xl p-3 w-full mt-1 mb-3" />
            <label className="text-xs font-semibold opacity-70">রেফারেন্স / TrxID</label>
            <input value={trxId} onChange={(e) => setTrxId(e.target.value)} className="border rounded-xl p-3 w-full mt-1 mb-3" placeholder="যেমনঃ 8N7X2KQY1P" />
            <button onClick={submit} className="bg-leaf2 text-white font-bold py-3 rounded-xl w-full">যাচাই করতে পাঠান</button>
            {msg && <div className="text-xs text-leaf2 font-semibold mt-2">{msg}</div>}
          </div>
        )}

        {isAdmin && (
          <div className="card p-4">
            <div className="font-semibold mb-2">TrxID দিয়ে পেমেন্ট খুঁজুন</div>
            <div className="flex gap-2 mb-3">
              <input value={searchTrx} onChange={(e) => setSearchTrx(e.target.value)} className="border rounded-xl p-3 flex-1" placeholder="TrxID লিখুন" />
              <button onClick={search} className="bg-leaf2 text-white font-bold px-4 rounded-xl">খুঁজুন</button>
            </div>
            {foundPayments.map((p) => (
              <div key={p.id} className="flex justify-between items-center py-2 border-t">
                <div>
                  <div className="font-semibold text-sm">TrxID: {p.trxId}</div>
                  <div className="text-xs opacity-60">৳{p.amount} · {p.method} · {p.status}</div>
                </div>
                {p.status !== "verified" && (
                  <button onClick={() => approve(p.id)} className="bg-leaf2 text-white text-xs font-bold px-3 py-1.5 rounded-full">অনুমোদন</button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      <BottomNav />
    </div>
  );
}
