"use client";
import { useState } from "react";
import { loginUser, registerCustomer, requestPasswordReset, loginWithGoogle } from "@/lib/auth";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [mode, setMode] = useState("login"); // login | signup
  const [form, setForm] = useState({ email: "", password: "", name: "", phone: "", refCode: "", rememberMe: true });
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const onChange = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    setErr("");
    setLoading(true);
    try {
      if (mode === "login") {
        await loginUser({ email: form.email, password: form.password, rememberMe: form.rememberMe });
      } else {
        await registerCustomer({
          email: form.email,
          password: form.password,
          name: form.name,
          phone: form.phone,
          referredByCode: form.refCode || null,
        });
      }
      router.push("/");
    } catch (e) {
      setErr(e.message.replace("Firebase: ", ""));
    } finally {
      setLoading(false);
    }
  };

  const submitGoogle = async () => {
    setErr("");
    setLoading(true);
    try {
      await loginWithGoogle({ rememberMe: form.rememberMe, referredByCode: form.refCode || null });
      router.push("/");
    } catch (e) {
      setErr(e.message.replace("Firebase: ", ""));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-5 pt-10">
      <div className="text-center mb-6">
        <img src="/icon-192.png" className="w-16 h-16 rounded-full mx-auto mb-2" />
        <div className="font-display font-bold text-xl">মাছের বাজার</div>
        <div className="text-xs opacity-60">{mode === "login" ? "আপনার অ্যাকাউন্টে প্রবেশ করুন" : "নতুন অ্যাকাউন্ট তৈরি করুন"}</div>
      </div>

      <div className="flex flex-col gap-3">
        <button
          onClick={submitGoogle}
          disabled={loading}
          className="flex items-center justify-center gap-2 border rounded-xl py-3 font-semibold bg-white"
        >
          <svg width="18" height="18" viewBox="0 0 48 48">
            <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.9 32.7 29.4 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.1 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z"/>
            <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 15.9 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.1 29.5 4 24 4 16 4 9 8.6 6.3 14.7z"/>
            <path fill="#4CAF50" d="M24 44c5.3 0 10.2-2 13.8-5.4l-6.4-5.4C29.3 34.9 26.8 36 24 36c-5.3 0-9.8-3.3-11.3-8l-6.6 5.1C9 39.4 16 44 24 44z"/>
            <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.9 2.5-2.6 4.6-4.9 6.1l6.4 5.4C40.5 36.9 44 31.1 44 24c0-1.3-.1-2.7-.4-3.5z"/>
          </svg>
          Google দিয়ে চালিয়ে যান
        </button>

        <div className="flex items-center gap-2 text-xs opacity-50">
          <div className="flex-1 h-px bg-gray-300" /> অথবা <div className="flex-1 h-px bg-gray-300" />
        </div>

        {mode === "signup" && (
          <>
            <input placeholder="নাম" className="border rounded-xl p-3" value={form.name} onChange={(e) => onChange("name", e.target.value)} />
            <input placeholder="মোবাইল নম্বর" className="border rounded-xl p-3" value={form.phone} onChange={(e) => onChange("phone", e.target.value)} />
            <input placeholder="রেফারেল কোড (ঐচ্ছিক)" className="border rounded-xl p-3" value={form.refCode} onChange={(e) => onChange("refCode", e.target.value)} />
          </>
        )}
        <input placeholder="ইমেইল" type="email" className="border rounded-xl p-3" value={form.email} onChange={(e) => onChange("email", e.target.value)} />
        <input placeholder="পাসওয়ার্ড" type="password" className="border rounded-xl p-3" value={form.password} onChange={(e) => onChange("password", e.target.value)} />

        {mode === "login" && (
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.rememberMe} onChange={(e) => onChange("rememberMe", e.target.checked)} />
            মনে রাখুন
          </label>
        )}

        {err && <div className="text-due text-sm">{err}</div>}

        <button disabled={loading} onClick={submit} className="bg-leaf2 text-white font-bold py-3 rounded-xl">
          {loading ? "অপেক্ষা করুন..." : mode === "login" ? "প্রবেশ করুন" : "সাইন আপ করুন"}
        </button>

        {mode === "login" && (
          <button className="text-leaf2 text-xs font-semibold" onClick={() => requestPasswordReset(form.email)}>
            পাসওয়ার্ড ভুলে গেছেন?
          </button>
        )}

        <button
          className="text-sm font-semibold opacity-70"
          onClick={() => setMode(mode === "login" ? "signup" : "login")}
        >
          {mode === "login" ? "নতুন অ্যাকাউন্ট তৈরি করুন" : "লগইন করুন"}
        </button>
      </div>
    </div>
  );
}
