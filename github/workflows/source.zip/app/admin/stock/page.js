"use client";
import { useEffect, useState } from "react";
import { listenToFishCatalog, addFish, updateFishPrice, updateFishStock, updateFishImage } from "@/lib/firestore-helpers";
import { uploadFishImage } from "@/lib/upload";
import BottomNav from "@/components/BottomNav";
import FishCard from "@/components/FishCard";

export default function AdminStock() {
  const [fish, setFish] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", price: "", stock: "", category: "নদী", unit: "কেজি" });
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [editImageFile, setEditImageFile] = useState(null);

  useEffect(() => {
    const unsub = listenToFishCatalog(setFish);
    return () => unsub();
  }, []);

  const pickImage = (file, setFileFn, setPreviewFn) => {
    setFileFn(file || null);
    if (setPreviewFn) {
      if (file) setPreviewFn(URL.createObjectURL(file));
      else setPreviewFn(null);
    }
  };

  const submitNewFish = async () => {
    if (!form.name || !form.price) return;
    setUploading(true);
    try {
      // প্রথমে মাছ যোগ করা হয় (ছবি ছাড়া) — নতুন fishId দরকার Storage পাথের জন্য
      const docRef = await addFish({
        name: form.name,
        price: parseFloat(form.price),
        stock: parseFloat(form.stock) || 0,
        category: form.category,
        unit: form.unit,
        imageUrl: null,
      });

      if (imageFile) {
        // রিয়েল ছবি আপলোড চেষ্টা করা হয়। ব্যর্থ হলে uploadFishImage null
        // রিটার্ন করে — তখন imageUrl null-ই থেকে যায় এবং কার্ডে ইমোজি দেখাবে।
        const url = await uploadFishImage(imageFile, docRef.id);
        if (url) await updateFishImage(docRef.id, url);
      }
    } finally {
      setUploading(false);
    }
    setForm({ name: "", price: "", stock: "", category: "নদী", unit: "কেজি" });
    pickImage(null, setImageFile, setImagePreview);
    setShowAdd(false);
  };

  const submitPriceEdit = async (newPrice) => {
    await updateFishPrice(editing.id, parseFloat(newPrice));
    if (editImageFile) {
      setUploading(true);
      const url = await uploadFishImage(editImageFile, editing.id);
      if (url) await updateFishImage(editing.id, url);
      setUploading(false);
    }
    setEditImageFile(null);
    setEditing(null);
  };

  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 rounded-b-3xl">
        <div className="font-display font-bold text-lg">স্টক ব্যবস্থাপনা</div>
        <div className="text-xs opacity-85">মোট {fish.reduce((a, f) => a + (f.stock || 0), 0)} কেজি মজুদ আছে</div>
      </div>

      <div className="p-4 flex flex-col gap-2.5">
        {fish.map((f) => (
          <FishCard key={f.id} fish={f} isAdmin onEditPrice={setEditing} />
        ))}
      </div>

      <button
        onClick={() => setShowAdd(true)}
        className="fixed bottom-20 right-1/2 translate-x-[170px] w-14 h-14 rounded-full bg-gold text-white text-2xl shadow-lg z-40"
      >
        +
      </button>

      {showAdd && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center" onClick={(e) => e.target === e.currentTarget && setShowAdd(false)}>
          <div className="bg-cream w-full max-w-[460px] rounded-t-3xl p-5">
            <div className="font-display font-bold text-lg mb-3">নতুন মাছ ও দাম যোগ করুন</div>
            <div className="flex flex-col gap-2.5">
              <input placeholder="মাছের নাম" className="border rounded-xl p-3" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <div className="flex gap-2">
                <input placeholder="দাম (৳)" type="number" className="border rounded-xl p-3 flex-1" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
                <input placeholder="স্টক" type="number" className="border rounded-xl p-3 flex-1" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
              </div>
              <select className="border rounded-xl p-3" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                <option>নদী</option>
                <option>খামার</option>
              </select>

              <div className="border rounded-xl p-3 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-mint flex items-center justify-center text-xl overflow-hidden shrink-0">
                  {imagePreview ? (
                    <img src={imagePreview} alt="preview" className="w-full h-full object-cover" />
                  ) : (
                    "🐟"
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <label className="text-[12px] font-semibold text-leaf2 cursor-pointer">
                    রিয়েল ছবি আপলোড করুন (ঐচ্ছিক)
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={(e) => pickImage(e.target.files?.[0], setImageFile, setImagePreview)}
                    />
                  </label>
                  <div className="text-[10.5px] opacity-55 mt-0.5">
                    ছবি না দিলে ডিফল্ট 🐟 ইমোজি দেখানো হবে
                  </div>
                </div>
              </div>

              <button onClick={submitNewFish} disabled={uploading} className="bg-leaf2 text-white font-bold py-3 rounded-xl disabled:opacity-60">
                {uploading ? "যোগ করা হচ্ছে..." : "যোগ করুন"}
              </button>
              <button onClick={() => setShowAdd(false)} className="border py-3 rounded-xl font-semibold">বাতিল</button>
            </div>
          </div>
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center" onClick={(e) => e.target === e.currentTarget && setEditing(null)}>
          <div className="bg-cream w-full max-w-[460px] rounded-t-3xl p-5">
            <div className="font-display font-bold text-lg mb-1">{editing.name} — দাম পরিবর্তন</div>
            <div className="text-xs opacity-60 mb-3">বর্তমান দাম ৳{editing.price}</div>
            <input
              id="newPriceInput"
              type="number"
              placeholder="নতুন দাম লিখুন"
              className="border rounded-xl p-3 w-full mb-3"
            />

            <div className="border rounded-xl p-3 flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-xl bg-mint flex items-center justify-center text-xl overflow-hidden shrink-0">
                {editImageFile ? (
                  <img src={URL.createObjectURL(editImageFile)} alt="preview" className="w-full h-full object-cover" />
                ) : editing.imageUrl ? (
                  <img src={editing.imageUrl} alt={editing.name} className="w-full h-full object-cover" />
                ) : (
                  "🐟"
                )}
              </div>
              <div className="flex-1 min-w-0">
                <label className="text-[12px] font-semibold text-leaf2 cursor-pointer">
                  {editing.imageUrl ? "ছবি পরিবর্তন করুন" : "রিয়েল ছবি আপলোড করুন (ঐচ্ছিক)"}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={(e) => setEditImageFile(e.target.files?.[0] || null)}
                  />
                </label>
                <div className="text-[10.5px] opacity-55 mt-0.5">ছবি না দিলে 🐟 ইমোজি থেকে যাবে</div>
              </div>
            </div>

            <button
              onClick={() => submitPriceEdit(document.getElementById("newPriceInput").value)}
              disabled={uploading}
              className="bg-leaf2 text-white font-bold py-3 rounded-xl w-full disabled:opacity-60"
            >
              {uploading ? "হালনাগাদ করা হচ্ছে..." : "হালনাগাদ করুন"}
            </button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
