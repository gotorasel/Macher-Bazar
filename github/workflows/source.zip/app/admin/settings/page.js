"use client";
import { useEffect, useState } from "react";
import { listenToPaymentSettings, updatePaymentSettings } from "@/lib/firestore-helpers";
import BottomNav from "@/components/BottomNav";

export default function AdminSettings() {
  const [bkashNumber, setBkash] = useState("");
  const [nagadNumber, setNagad] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const unsub = listenToPaymentSettings((s) => {
      setBkash(s.bkashNumber || "");
      setNagad(s.nagadNumber || "");
    });
    return () => unsub();
  }, []);

  const save = async () => {
    await updatePaymentSettings({ bkashNumber, nagadNumber });
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 rounded-b-3xl">
        <div className="font-display font-bold text-lg">পেমেন্ট নম্বর সেটিংস</div>
        <div className="text-xs opacity-85">bKash / Nagad নম্বর এখান থেকে যেকোনো সময় পরিবর্তন করুন</div>
      </div>
      <div className="p-4 flex flex-col gap-3">
        <div className="card p-4">
          <label className="text-xs font-semibold opacity-70">bKash নম্বর</label>
          <input value={bkashNumber} onChange={(e) => setBkash(e.target.value)} className="border rounded-xl p-3 w-full mt-1" placeholder="01XXXXXXXXX" />
        </div>
        <div className="card p-4">
          <label className="text-xs font-semibold opacity-70">Nagad নম্বর</label>
          <input value={nagadNumber} onChange={(e) => setNagad(e.target.value)} className="border rounded-xl p-3 w-full mt-1" placeholder="01XXXXXXXXX" />
        </div>
        <button onClick={save} className="bg-leaf2 text-white font-bold py-3 rounded-xl">
          {saved ? "সংরক্ষিত হয়েছে ✓" : "সংরক্ষণ করুন"}
        </button>
      </div>
      <BottomNav />
    </div>
  );
}
