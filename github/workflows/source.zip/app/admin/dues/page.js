"use client";
import { useEffect, useState } from "react";
import { listenToAllDues, sendDueReminder } from "@/lib/firestore-helpers";
import BottomNav from "@/components/BottomNav";

export default function AdminDues() {
  const [dues, setDues] = useState([]);
  useEffect(() => listenToAllDues(setDues), []);

  return (
    <div>
      <div className="bg-gradient-to-br from-deep to-leaf text-white p-4 rounded-b-3xl">
        <div className="font-display font-bold text-lg">সকল বাকির খাতা</div>
      </div>
      <div className="p-4 flex flex-col gap-2.5">
        {dues.length === 0 && <div className="card p-6 text-center opacity-60">কোনো বাকি নেই</div>}
        {dues.map((d) => (
          <div key={d.id} className="card p-3 flex justify-between items-center">
            <div>
              <div className="font-bold text-sm">{d.userId}</div>
              <div className="text-xs opacity-60">অর্ডার: {d.orderId?.slice(0, 8)}</div>
            </div>
            <div className="text-right">
              <div className="font-bold text-due">৳{d.amount?.toLocaleString()}</div>
              <button
                onClick={() => sendDueReminder(d.id, d.userId)}
                className="text-xs font-semibold px-2 py-1 rounded-full bg-red-100 text-due mt-1"
              >
                রিমাইন্ডার
              </button>
            </div>
          </div>
        ))}
      </div>
      <BottomNav />
    </div>
  );
}
