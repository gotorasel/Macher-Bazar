/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        deep: "#0F3D2E",
        leaf: "#1E6E4C",
        leaf2: "#2F8F63",
        mint: "#DCF0E3",
        cream: "#FBF8F1",
        gold: "#C98A2C",
        due: "#B5432B",
      },
      fontFamily: {
        display: ["Baloo Da 2", "sans-serif"],
        body: ["Hind Siliguri", "sans-serif"],
      },
    },
  },
  plugins: [],
};
