# মাছের বাজার — Next.js + Firebase

আপনার real Firebase project (`agro-4175b`) দিয়ে এই কোড লেখা হয়েছে — `lib/firebase.js` এ আপনার আসল config বসানো আছে।

## এই কোডে যা আসল (mock না):
- Firebase Auth দিয়ে সত্যিকারের লগইন/সাইনআপ
- Firestore দিয়ে সত্যিকারের ডাটাবেস (fish, orders, dues, payments, chats, notifications, users)
- Firestore Security Rules (`firestore.rules`) — কাস্টমার শুধু নিজের ডেটা দেখবে, শুধু অ্যাডমিন দাম/স্টক পরিবর্তন করতে পারবে
- দাম পরিবর্তন করলে automatically পুরনো দাম strikethrough হিসেবে সংরক্ষিত হয়
- লয়্যালটি কয়েন (১০০ টাকা = ১ কয়েন), রেফারেল কমিশন — অটো হিসাব হয়
- গোপন অ্যাডমিন রুট: `/secure-admin-login` + কীবোর্ড শর্টকাট Ctrl+Shift+A
- অফলাইন পার্সিস্টেন্স (Firestore IndexedDB cache) — নেট চলে গেলেও অ্যাপ কাজ করবে, নেট এলে auto-sync হবে
- PWA manifest + service worker (next-pwa)

## যা এখনো বাকি (ঐচ্ছিক — চাইলে পরে দিন):

1. ✅ প্রথম অ্যাডমিন: gotorasel@gmail.com — সেটআপ ধাপ `ADMIN_SETUP.md` তে
2. ✅ bKash: 01764842883, Nagad: 01626871416 — অ্যাডমিন প্যানেলের `/admin/settings` থেকে পরিবর্তনযোগ্য
3. ✅ Google Sign-In যোগ করা হয়েছে (কাস্টমার লগইন পেজে)
4. ✅ কোনো ডোমেইন/হোস্টিং নেই → Firebase-এর ফ্রি সাবডোমেইন (`agro-4175b.web.app`) ব্যবহার হবে, সম্পূর্ণ ফ্রি
5. **Google AdSense**: আপনার Publisher ID (`ca-pub-xxxxxxxxxx`) ও Ad Slot ID দিলে ব্যানার বসিয়ে দেব — deploy হওয়ার পর AdSense-এ `agro-4175b.web.app` সাইট হিসেবে যোগ করে ভেরিফাই করবেন (ফ্রি, ডোমেইন লাগবে না)
6. **Firebase Storage**: মাছের real ছবি আপলোড করতে চাইলে Firebase Console-এ Storage enable করা আছে কিনা জানাবেন (এখন ইমোজি আইকন ব্যবহার হচ্ছে — এটাও সম্পূর্ণ ফ্রি বিকল্প, চাইলে এভাবেই রাখা যায়)

## চালানোর ধাপ (আপনার/Claude Code-এর কম্পিউটারে):

```bash
npm install
npm run dev        # লোকাল টেস্ট: http://localhost:3000

# Deploy করতে:
npm install -g firebase-tools
firebase login
firebase deploy --only firestore:rules
npm run build
firebase deploy --only hosting
```

## প্রজেক্ট স্ট্রাকচার
```
app/
  page.js                 → হোম (ক্যাটালগ)
  login/page.js            → কাস্টমার লগইন/সাইনআপ
  secure-admin-login/page.js → গোপন অ্যাডমিন লগইন
  admin/stock/page.js      → স্টক ও দাম ব্যবস্থাপনা
  admin/dues/page.js       → বাকির খাতা
  admin/settings/page.js   → bKash/Nagad নম্বর পরিবর্তন
  pay/page.js               → পেমেন্ট রেফারেন্স জমা ও অ্যাডমিন ভেরিফিকেশন
  checkout/page.js         → অর্ডার/চেকআউট
  profile/page.js          → প্রোফাইল, অর্ডার হিস্টরি
  offer/page.js            → লয়্যালটি/রেফারেল
lib/
  firebase.js              → Firebase config + init
  auth.js                  → লগইন/সাইনআপ/অ্যাডমিন যাচাই
  firestore-helpers.js     → সব ডাটাবেস ফাংশন
firestore.rules            → নিরাপত্তা নিয়ম
```

---

## 🔧 এই ভার্সনে যা ঠিক/যোগ করা হয়েছে (আপডেট)

1. **রিয়েল মাছের ছবি আপলোড** — অ্যাডমিন প্যানেলের "স্টক ব্যবস্থাপনা" পেজে এখন
   নতুন মাছ যোগ করার সময় বা আগের মাছের দাম পরিবর্তনের সময় সত্যিকারের ছবি
   আপলোড করার অপশন আছে (`lib/upload.js`, Firebase Storage ব্যবহার করে)।
   - ছবি আপলোড করলে সেই রিয়েল ছবি কার্ডে দেখাবে।
   - ছবি আপলোড না করলে, বা Storage enable করা না থাকলে/আপলোড ব্যর্থ হলে,
     স্বয়ংক্রিয়ভাবে ডিফল্ট 🐟 ইমোজি দেখানো হবে — অ্যাপ ভাঙবে না।
   - Firebase Console → Storage → Get started করে Storage চালু করে
     `firebase deploy --only storage` দিয়ে `storage.rules` আপলোড করে দিন।
2. **প্রজেক্ট স্ট্রাকচার ফ্ল্যাট করা হয়েছে** — আগের zip-এ একটি বাড়তি বাইরের
   `machher-bazar/` ফোল্ডার ছিল, যা GitHub রিপোর root-এ থাকলে Vercel
   `package.json` খুঁজে পেত না এবং deploy 404 (`NOT_FOUND`) দেখাত। এখন
   `package.json`, `app/`, `lib/` ইত্যাদি সরাসরি সবচেয়ে উপরের লেভেলে আছে।
3. **`.gitignore` যোগ করা হয়েছে** — যাতে `node_modules/`, `.next/` ভুলে GitHub-এ
   push না হয়ে যায়।
4. একটি ভাঙা/অচেনা ফোল্ডার (`app/{secure-admin-login,...}`) মুছে ফেলা হয়েছে,
   যা আগের zip তৈরির সময় ভুল কমান্ডের কারণে তৈরি হয়েছিল।
