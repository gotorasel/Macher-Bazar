"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "/", label: "হোম" },
  { href: "/admin/stock", label: "স্টক" },
  { href: "/offer", label: "অফার" },
  { href: "/price", label: "প্রাইস" },
  { href: "/profile", label: "প্রোফাইল" },
];

export default function BottomNav() {
  const pathname = usePathname();
  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[460px] bg-white dark:bg-[#0F1F17] border-t border-[#CFE7D9] dark:border-[#1D3A2C] flex justify-around py-2 z-40">
      {items.map((it) => (
        <Link
          key={it.href}
          href={it.href}
          className={`flex flex-col items-center text-[11px] font-semibold px-2 ${
            pathname === it.href ? "text-leaf2 opacity-100" : "opacity-50"
          }`}
        >
          {it.label}
        </Link>
      ))}
    </div>
  );
}
