"use client";

export default function FishCard({ fish, isAdmin, onAddToCart, onEditPrice }) {
  return (
    <div className="card p-3 flex gap-3 items-center">
      <div className="w-14 h-14 rounded-2xl bg-mint flex items-center justify-center text-2xl shrink-0 overflow-hidden">
        {fish.imageUrl ? (
          // রিয়েল ছবি আপলোড করা থাকলে সেটি দেখানো হয়
          <img
            src={fish.imageUrl}
            alt={fish.name}
            className="w-full h-full object-cover"
            onError={(e) => {
              // ছবি লোড ব্যর্থ হলে (লিংক নষ্ট/মুছে গেলে) ইমোজিতে ফিরে যায়
              e.currentTarget.style.display = "none";
              e.currentTarget.parentElement.textContent = "🐟";
            }}
          />
        ) : (
          // ছবি না থাকলে ইমোজি মাছ দেখানো হয়
          "🐟"
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between items-start">
          <div>
            <div className="font-bold text-[14.5px]">{fish.name}</div>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-mint text-leaf2 font-semibold">
              {fish.category}
            </span>
          </div>
          <div className="text-right">
            {fish.oldPrice ? <div className="fish-strike">৳{fish.oldPrice}</div> : null}
            <div className="font-bold text-leaf2 text-[15px]">
              ৳{fish.price}
              <span className="text-[11px] font-medium opacity-60">/{fish.unit}</span>
            </div>
          </div>
        </div>
        <div className="flex justify-between items-center mt-1.5">
          <span className="text-[11px] opacity-55">স্টক: {fish.stock} {fish.unit}</span>
          {isAdmin ? (
            <button
              onClick={() => onEditPrice(fish)}
              className="text-[12px] font-semibold px-3 py-1.5 rounded-full bg-mint text-leaf2"
            >
              দাম পরিবর্তন
            </button>
          ) : (
            <button
              onClick={() => onAddToCart(fish)}
              className="text-[12px] font-semibold px-3 py-1.5 rounded-full bg-leaf2 text-white"
            >
              কার্টে যোগ করুন
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
