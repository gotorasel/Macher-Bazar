# প্রথম অ্যাডমিন অ্যাকাউন্ট তৈরি করার ধাপ

আপনার দেওয়া তথ্য: **gotorasel@gmail.com**

নিরাপত্তার জন্য পাসওয়ার্ডটা আমি কোনো ফাইলে লিখে রাখিনি — নিচের ধাপে আপনি নিজে বসাবেন।

## ধাপ ১: Firebase Console-এ ইউজার তৈরি করুন
1. https://console.firebase.google.com এ যান → প্রজেক্ট **agro-4175b** খুলুন
2. বাম মেনু থেকে **Authentication** → **Users** ট্যাব → **Add user**
3. Email: `gotorasel@gmail.com`, Password: আপনার পাসওয়ার্ড দিন → **Add user**
4. তৈরি হওয়া ইউজারের **User UID** কপি করুন (এটা লম্বা একটা কোড, যেমন `aB3xY...`)

## ধাপ ২: Google Sign-In চালু করুন
1. Authentication → **Sign-in method** ট্যাব
2. **Email/Password** enable করুন (যদি না থাকে)
3. **Google** provider-এ ক্লিক করে **Enable** করুন, support email দিয়ে Save করুন

## ধাপ ৩: Firestore-এ অ্যাডমিন প্রোফাইল বানান
1. বাম মেনু থেকে **Firestore Database** → **Start collection**
2. Collection ID: `users`
3. Document ID: ধাপ ১ থেকে কপি করা **User UID** বসান (অটো-জেনারেট না করে ম্যানুয়ালি বসাবেন)
4. নিচের ফিল্ডগুলো যোগ করুন:
   - `name` (string) → `Rasel`
   - `role` (string) → `admin`
   - `coins` (number) → `0`
   - `wallet` (number) → `0`
5. **Save**

## ধাপ ৪: পেমেন্ট নম্বর সংরক্ষণ করুন
আরেকটা collection বানান:
1. Collection ID: `settings`
2. Document ID: `payment`
3. ফিল্ড:
   - `bkashNumber` (string) → `01764842883`
   - `nagadNumber` (string) → `01626871416`
4. **Save**

(এটা একবার ম্যানুয়ালি বসিয়ে দিলে পরে অ্যাডমিন প্যানেলের **Settings** পেজ (`/admin/settings`) থেকেই যেকোনো সময় বদলাতে পারবেন — কোড পাল্টানোর দরকার নেই)

## ধাপ ৫: লগইন টেস্ট করুন
অ্যাপ চালু করে (`npm run dev`) `/secure-admin-login` এ যান অথবা কীবোর্ডে **Ctrl+Shift+A** চাপুন, তারপর ইমেইল-পাসওয়ার্ড দিয়ে ঢুকুন।

## Google Sign-In authorized domain
Deploy করার পর আপনার Firebase Hosting URL (`agro-4175b.web.app`) স্বয়ংক্রিয়ভাবেই authorized থাকবে। লোকাল টেস্টে `localhost` ও ডিফল্টভাবে authorized থাকে।
